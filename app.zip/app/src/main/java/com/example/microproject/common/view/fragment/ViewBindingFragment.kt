package com.example.microproject.common.view.fragment

import androidx.viewbinding.ViewBinding

open class ViewBindingFragment<T : ViewBinding>() : MvvmFragment() {
    // Common code implementation class for Fragment view binding
}