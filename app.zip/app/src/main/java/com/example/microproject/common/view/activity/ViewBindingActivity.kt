import androidx.viewbinding.ViewBinding

// Common ViewBindingActivity code use for activity view binding

open class ViewBindingActivity<T : ViewBinding>() : MvvmActivity() {
    // Common code implementation class for Activity view binding
}