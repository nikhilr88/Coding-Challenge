package com.example.microproject.common.view.fragment

import androidx.fragment.app.Fragment

open class MvvmFragment : Fragment() {
    // Common code implementation class for Fragment
}