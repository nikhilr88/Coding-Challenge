import androidx.appcompat.app.AppCompatActivity

open class MvvmActivity : AppCompatActivity() {
    // Common code implementation class for Activity
}