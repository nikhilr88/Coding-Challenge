package com.example.microproject.account.login.data.util

data class UserInfo(val firstName: String, val email: String, val customerId : String)