package com.example.microproject.common.viewmodel

import androidx.lifecycle.ViewModel

open class BaseViewModel : ViewModel() {
    // Common code implementation class for ViewModel
}