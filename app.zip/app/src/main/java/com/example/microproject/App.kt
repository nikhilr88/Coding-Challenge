package com.example.microproject

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}