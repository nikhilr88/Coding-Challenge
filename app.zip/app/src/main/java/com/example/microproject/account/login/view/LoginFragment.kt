package com.example.microproject.account.login.view

import android.os.Bundle
import android.view.View
import com.example.microproject.common.view.fragment.MvvmFragment

class LoginFragment : MvvmFragment() {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    fun startApp(){
        // After login Redirect to Home screen
    }
}