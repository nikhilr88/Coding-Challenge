package com.example.microproject.home.data.util

data class CarInfo(
    val customerId: String,
    val maxSpeed: Int
)